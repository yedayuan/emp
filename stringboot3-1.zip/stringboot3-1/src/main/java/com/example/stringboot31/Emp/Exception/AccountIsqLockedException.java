package com.example.stringboot31.Emp.Exception;

import com.example.stringboot31.Emp.Results.Result;
import com.example.stringboot31.Emp.entity.Emp;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


//@RestControllerAdvice
public class AccountIsqLockedException extends RuntimeException{


}

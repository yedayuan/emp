package com.example.stringboot31.Emp.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmpDTO {
    /*员工名*/
    @TableField(exist = false)
    private String name;
    /*员工用户名*/
    @TableField(exist = false)
    private String empname;
    /* 密码*/
    @TableField(exist = false)
    private String password;
    /* 电话*/
    @TableField(exist = false)
    private Integer phone;
    /* 性别*/
    @TableField(exist = false)
    private String sex;
    /* 身份证号码*/
    @TableField(exist = false)
    private Integer idNumber;

}

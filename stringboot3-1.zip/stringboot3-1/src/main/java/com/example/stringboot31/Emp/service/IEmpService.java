package com.example.stringboot31.Emp.service;

import com.example.stringboot31.Emp.entity.Emp;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.stringboot31.Emp.entity.EmpDTO;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author 叶大源
 * @since 2023-07-24
 */
public interface IEmpService extends IService<Emp> {
    /*查询操作*/
    Emp select(long id);

    /*员工登录*/
    Emp login(EmpDTO empDTO);

    /*新增员工*/
    void empinsert(EmpDTO empDTO);
    /*分页查询*/
    List<Emp> emppage(Integer current, Integer size, String name, Integer sex, LocalDateTime createTime, LocalDateTime updateTime);

    /*多查询*/
    List<Emp> empselect(List<Integer> ids);

    /*删除员工*/
    void empremoveByIds(List<Integer> ids);
/*修改*/
    void empupdate(EmpDTO empDTO);
}

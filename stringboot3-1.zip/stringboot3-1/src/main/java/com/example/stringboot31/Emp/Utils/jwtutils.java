package com.example.stringboot31.Emp.Utils;





import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;
import java.util.Map;


public class jwtutils {
    private static String signkey="token";
    private static Long expire=432000l;
    //生成jwts令牌,需要引入依赖 HS256-HS384-HS512-RS256 工具类


    public static String generateJWT(Map<String,Object> claims){
    //    Map<String, Object> claims = new HashMap<>();
     //   claims.put("id","1");
      //  claims.put("name","dayuan");
        String jwt = Jwts.builder()
                .signWith(SignatureAlgorithm.HS256,signkey )//signkey)签名算法
                .setClaims(claims)//自定义内容
                .setExpiration(new Date(System.currentTimeMillis() + expire ))//设置时间1小时
                .compact();//已生成jwts令牌
        return jwt;
    }
    //解析工具类jwts令牌
 /*   public  static Claims parseJWT(String jwt){
        Claims claims = Jwts.parser()//
                .setSigningKey(signkey)
                .parseClaimsJws(jwt)//
                .getBody();
        return claims;
    }*/
}

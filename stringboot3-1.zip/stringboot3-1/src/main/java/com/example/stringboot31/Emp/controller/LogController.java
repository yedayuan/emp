package com.example.stringboot31.Emp.controller;


import com.example.stringboot31.Emp.Configurations.jwtPropertiss;
import com.example.stringboot31.Emp.Results.Result;
import com.example.stringboot31.Emp.entity.Emp;
import com.example.stringboot31.Emp.entity.EmpDTO;
import com.example.stringboot31.Emp.entity.emploginVO;
import com.example.stringboot31.Emp.service.IEmpService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author 叶大源
 * @since 2023-07-24
 */
@ApiOperation("登录接口")
@RestController
@Log4j2
@RequestMapping("/emp")
@RequiredArgsConstructor//构造注入
public class LogController {
    private static String signkey = "itheima";//签名算法
    private final jwtPropertiss jwtpropertiss;

    @Autowired
    private IEmpService empService;


    @ApiOperation("登录")
    @PostMapping("/login")
    public Result<Emp> login(@RequestBody EmpDTO empDTO) {
        log.info("员工登录:{}", empDTO);
        Emp emp = empService.login(empDTO);
        if (emp == null) {
            return Result.error("用户或密码错误");

        }
        //生成令牌

        //生成jwts令牌,需要引入依赖 HS256-HS384-HS512-RS256
        Map<String, Object> claims = new HashMap<>();
        claims.put("id", emp.getId());
        claims.put("empname", emp.getEmpname());
        String token = Jwts.builder()
                .signWith(SignatureAlgorithm.HS256, jwtpropertiss.getAdminSecretKey())//签名算法
                .setClaims(claims)//自定义内容
                .setExpiration(new Date(System.currentTimeMillis() + jwtpropertiss.getAdminTtl()))//设置时间1小时
                .compact();//已生成jwts令牌

        //jwts令牌已存入emploginVO中
        emploginVO emploginVo = emploginVO.builder()
                .id(emp.getId())
                .empname(emp.getEmpname())
                .name(emp.getName())
                .token(token)
                .build();
        return Result.success(emploginVo);
    }

    //解析工具类jwts令牌

    public static Claims parseJWT(String jwt) {
        Claims claims = Jwts.parser()//
                .setSigningKey(signkey)
                .parseClaimsJws(jwt)//
                .getBody();
        return claims;
    }

}




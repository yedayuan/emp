package com.example.stringboot31;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.boot.web.servlet.ServletComponentScan;

//@StringBootApplication开始注解的事务管理
@ConfigurationPropertiesScan(basePackages ="com.example.stringboot31.Emp.Configurations")//配置类扫描@Data包名
@ServletComponentScan //开始servler组件支持,开始过滤器支持
@SpringBootApplication
@MapperScan(basePackages = "com.example.stringboot31.Emp.mapper")//连接数据库 连接接口
public class Stringboot31Application {
    public static void main(String[] args) {
        SpringApplication.run(Stringboot31Application.class, args);
    }
}

package com.example.stringboot31.Emp.Exception;

import com.example.stringboot31.Emp.Results.Result;
import net.bytebuddy.implementation.bind.annotation.RuntimeType;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.sql.SQLIntegrityConstraintViolationException;

@RestControllerAdvice
//全局异常处理
public class ExceptionHandler {

@org.springframework.web.bind.annotation.ExceptionHandler
    private Result exceptionHandler(SQLIntegrityConstraintViolationException ex){

    String message = ex.getMessage();
    if (message.contains("Duplicate entry")) {
        String[] empname = message.split("");

      String msg = empname +"已存在";
      return Result.error(msg);
    }
    return Result.error("用户未知错误");
    }

/*全局异常类*/
     @org.springframework.web.bind.annotation.ExceptionHandler(Exception.class)
    public Result ex(Exception ex) {
        return Result.error("全局异常处理");
    }
}

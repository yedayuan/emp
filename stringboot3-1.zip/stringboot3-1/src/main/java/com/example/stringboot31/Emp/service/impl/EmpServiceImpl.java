package com.example.stringboot31.Emp.service.impl;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.stringboot31.Emp.Exception.AccountIsqLockedException;
import com.example.stringboot31.Emp.Exception.AccountNotFoundException;
import com.example.stringboot31.Emp.Exception.AsswordErrorException;
import com.example.stringboot31.Emp.entity.Emp;
import com.example.stringboot31.Emp.entity.EmpDTO;
import com.example.stringboot31.Emp.entity.pageVO;
import com.example.stringboot31.Emp.mapper.EmpMapper;
import com.example.stringboot31.Emp.service.IEmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author 叶大源
 * @since 2023-07-24
 */
@Service
public class EmpServiceImpl extends ServiceImpl<EmpMapper, Emp> implements IEmpService {
    @Autowired
    private EmpMapper empMapper;
    /*查询操作*/
    @Override
    public Emp select(long id) {
        Emp emp = empMapper.selectById(id);
        emp.setPassword("****");
        return emp;
    }
    /*员工登录*/
    @Override
    public Emp login(EmpDTO empDTO) {
        String empname = empDTO.getEmpname();
        String password = empDTO.getPassword();
        //密码加密
         password=  DigestUtils.md5DigestAsHex(password.getBytes());
     Emp emp =  empMapper.getloginEmpname(empname);
        if (emp == null) {
            /*账号不存在*/
           throw  new AccountNotFoundException();

        }
        if (!password.equals(emp.getPassword())) {
            /*密码不对*/
            throw  new AsswordErrorException();
        }
        if (emp.getStatus()==0) {
          /*  账户被锁定*/
            throw  new AccountIsqLockedException();
        }
        return emp;
    }
    /*新增员工*/
    @Override
    public void empinsert(EmpDTO empDTO) {
        Emp emps = Emp.builder()
                .name(empDTO.getName())
                .empname(empDTO.getEmpname())
                .password(DigestUtils.md5DigestAsHex("123456".getBytes()))//默认密码
                .phone(empDTO.getPhone())
                .sex(empDTO.getSex())
                .idNumber(empDTO.getIdNumber())
                .status(1)
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                //TODO
                .createId(1l)
                .updateId(1l)
                .build();
        empMapper.insert(emps);

    }
/*分页查询*/
    @Override
    public List<Emp> emppage(Integer current, Integer size, String name, Integer sex,
                             LocalDateTime createTime, LocalDateTime updateTime) {
        IPage<Emp> page = new Page<>(current, size);
        List<Emp> userselects = empMapper.userselect(page, name, sex, createTime, updateTime);
        for (Emp userselect : userselects) {
            userselect.setPassword("******");
        }
        pageVO pagevo = new pageVO();
        pagevo.setTotal(page.getTotal());//总条数常用
        pagevo.setCurrent(page.getCurrent());//当前页面第几页常用
        return userselects;
    }
/*查询ids*/
    @Override
    public List<Emp> empselect(List<Integer> ids) {
        List<Emp> emps = EmpMapper.selectByIds(ids);
        for (Emp emp : emps) {
            emp.setPassword("******");
        }
        return emps;
    }
/*删除员工*/
    @Override
    public void empremoveByIds(List<Integer> ids) {
        empMapper.empdeleteById(ids);
    }
    /*修改*/
    @Override
    public void empupdate(EmpDTO empDTO) {
        Emp emps = Emp.builder()
                .name(empDTO.getName())
                .empname(empDTO.getEmpname())
                .password(DigestUtils.md5DigestAsHex("123456".getBytes()))//默认密码
                .phone(empDTO.getPhone())
                .sex(empDTO.getSex())
                .idNumber(empDTO.getIdNumber())
                .status(1)
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                //TODO
                .createId(1l)
                .updateId(1l)
                .build();
        //TODU
        empMapper.empUpdate(emps);
    }



}

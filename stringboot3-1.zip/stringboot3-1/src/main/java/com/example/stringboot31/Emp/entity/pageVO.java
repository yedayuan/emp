package com.example.stringboot31.Emp.entity;

import io.swagger.annotations.ApiModel;
import lombok.Data;

//给前端返回结果列表
@Data
@ApiModel("分类分页查询返回")
public class pageVO {
    private long total;//总计录数常用
    private long current;//当前页面第几页常用
  //  private Integer size;//每页记录数
 //   private Integer pages;//总页数
  //  private String records;//分页数据

}

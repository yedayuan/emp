package com.example.stringboot31.Emp.Configurations;


import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "sky.jwt")
@Data
public class jwtPropertiss {
    /*jwt令牌配置类*/
    private String adminSecretKey;
    private  long  adminTtl;
    private  String adminTokenName;
}

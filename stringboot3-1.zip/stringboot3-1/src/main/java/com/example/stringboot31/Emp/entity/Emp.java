package com.example.stringboot31.Emp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author 叶大源
 * @since 2023-07-24
 */

@Builder
@Data
@TableName(value = "Emp")
@ApiModel("Emp实体类")
public class Emp implements Serializable {

    private static final long serialVersionUID = 1L;

    /* ID*/
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /* 姓名*/
    private String name;
    /* 员工ID*/
    private String empname;
    /* 密码*/
    private String password;
    /* 电话*/
    private Integer phone;
    /* 性别*/
    private String sex;
    /* 身份证号码*/
    private Integer idNumber;
    /*账户1正常,0锁定, */
    private Integer status;
    /* 开始时间*/
    private LocalDateTime createTime;
    /* 结束时间*/
    private LocalDateTime updateTime;
    /* 创建人id */
    private Long createId;
    /* 最后人ID*/
    private Long updateId;
}

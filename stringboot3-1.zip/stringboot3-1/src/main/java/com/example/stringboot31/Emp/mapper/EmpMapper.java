package com.example.stringboot31.Emp.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.stringboot31.Emp.entity.Emp;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 叶大源
 * @since 2023-07-24
 */
public interface EmpMapper extends BaseMapper<Emp> {

    /*多查询*/
    static List<Emp> selectByIds(List<Integer> ids) {
        return null;
    }


    /*查询 登录密码*/
    @Select("select * from Emp where empname=#{empname}")
    Emp getloginEmpname(String empname);

    /*删除员工*/
    void empdeleteById(List<Integer> ids);
    /*分页查询*/
    List<Emp> userselect(IPage<Emp> page, String name, Integer sex, LocalDateTime createTime,
                         LocalDateTime updateTime);


    void empUpdate(Emp emps);
}

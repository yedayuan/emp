package com.example.stringboot31.Emp.controller;

import java.time.LocalDateTime;
import java.util.List;


import com.example.stringboot31.Emp.Results.Result;
import com.example.stringboot31.Emp.entity.Emp;
import com.example.stringboot31.Emp.entity.EmpDTO;
import com.example.stringboot31.Emp.service.IEmpService;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@ApiOperation("增删改查操作接口")
@RestController
@Log4j2
@RequestMapping("/Emps")
public class EmpController {
    @Autowired
    private IEmpService empService;

    /* 查询操作*/
    @ApiOperation("查询")
    @GetMapping("/{id}")
    private Result<Emp> empselect(@PathVariable long id) {

        Emp emp = empService.select(id);
        return Result.success(emp);

    }

    @ApiOperation("新增员工")
    @PostMapping("/emp")
    private Result<Emp> empinsert(@RequestBody EmpDTO empDTO) {

        empService.empinsert(empDTO);
        return Result.success();
    }

    /*分页查询*/
    @ApiOperation("分页查询功能")
    @GetMapping("/d")
    private Result<EmpDTO> userselect(
            @RequestParam(defaultValue = "1") Integer current
            , @RequestParam(defaultValue = "2") Integer size
            , String name
            , Integer sex
            , @JsonFormat(pattern = "yyyy-MM-dd") LocalDateTime createTime
            , @JsonFormat(pattern = "yyyy-MM-dd") LocalDateTime updateTime
    ) {

        List<Emp> userlist = empService.emppage(current, size, name, sex, createTime, updateTime);
        return Result.success(userlist);
    }

    /*多查询*/
    @ApiOperation("查询ID路径功能")
    @GetMapping("/{ids}")
    private Result<Emp> userselect(@PathVariable List<Integer> ids) {
        List<Emp> lists = empService.empselect(ids);
        return Result.success(lists);
    }

    /*删除s*/
    @ApiOperation("ids删除功能")
    @DeleteMapping("/ids")
    private Result<Emp> delete(@RequestParam List<Integer> ids) {
        empService.empremoveByIds(ids);
        return Result.success();
    }

    /*修改用户*/
    @ApiOperation("userDTO修改用户功能")
    @PutMapping
    private Result<Emp> Update(@RequestBody EmpDTO empDTO) {
        log.info("编制用户:{}", empDTO);
        empService.empupdate(empDTO);
        return Result.success();
    }
}

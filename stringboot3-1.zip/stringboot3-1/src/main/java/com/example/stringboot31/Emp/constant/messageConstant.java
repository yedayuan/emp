package com.example.stringboot31.Emp.constant;

public class messageConstant {
    //常量类
    public static final String PASSWORDERROR="密码错误";
}

package com.example.stringboot31.Emp.Exception;


import com.example.stringboot31.Emp.Results.Result;
import com.example.stringboot31.Emp.entity.Emp;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.sql.SQLIntegrityConstraintViolationException;

@RestControllerAdvice
public class AccountNotFoundException extends RuntimeException {
  @ExceptionHandler(AccountNotFoundException.class)
private Result<Emp> accountException (){
  return Result.error("用户名不对") ;
}
  @ExceptionHandler(AccountIsqLockedException.class)
  private Result<Emp>AccountIsqLockedExceptio(){
    return Result.error("账户被锁定");
  }
  @ExceptionHandler(AsswordErrorException.class)
  private Result<Emp> passwordErrorException1(){
    return Result.error("密码不对");
  }
}

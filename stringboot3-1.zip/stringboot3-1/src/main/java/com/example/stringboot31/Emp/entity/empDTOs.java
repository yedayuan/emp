package com.example.stringboot31.Emp.entity;


import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
//前端传递过来数据
@ApiModel("前端传来的用户实体类")
public class empDTOs {  //implements Serializable

    @TableField(exist = false)
    private String name;/*姓名*/

    @TableField(exist = false)
    private String empname;/*姓名*/


    @TableField(exist = false)
    private Integer sex;/*性别*/

    @TableField(exist = false)
    private LocalDateTime createTime;//开始时间
    @TableField(exist = false)
    private LocalDateTime updateTime;//结束时间

    private Integer current;//  current分页列表数
    private Integer size;//size每页记录数(默认2)

}

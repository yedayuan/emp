package com.example.stringboot31;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
class Stringboot31ApplicationTests {

    @Test
    void contextLoads() {
    }
    @Test
    public void testgenJWT() {
        //生成jwts令牌,需要引入依赖 HS256-HS384-HS512-RS256
        Map<String, Object> map = new HashMap<>();
        map.put("id", "1");
        map.put("name", "dayuan");
        String jwt = Jwts.builder()
                .signWith(SignatureAlgorithm.HS256, "itheima")//签名算法
                .setClaims(map)//自定义内容
                .setExpiration(new Date(System.currentTimeMillis() + 3600 * 1000))//设置时间1小时
                .compact();//已生成jwts令牌
        System.out.println(jwt);
    }

}
